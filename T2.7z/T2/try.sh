cp specs/lista.txt .
mingw32-make
main.bin
rm *.bin *.txt
rm *.bt
