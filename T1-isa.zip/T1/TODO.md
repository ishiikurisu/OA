- [x] Criar criador de índices
  + Ele deverá ler uma lista e gerar dois índices: um primário e secundário
  - [x] Gerar índice primário
  - [x] Gerar índice secundário
    + Requer ordenar o índice primário
	+ Depois lidamos com isso hihihi
- [ ] Criar um ordenador de índices
  + Ordenando de uma maneira roubada até escrever o heapsort.
  + Sendo entregue roubado por não ter feito o heapsort ainda.
- [ ] Criar menu principal
  - [x] Incluir registro
  - [x] Excluir registro
  - [x] Atualizar registro
  - [x] Intercalar registros
