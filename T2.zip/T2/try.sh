cp specs/lista.txt .
mingw32-make
cat inlet.in | main.bin > outlet.in
rm *.bin
rm *.txt
rm *.bt
